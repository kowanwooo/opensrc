MySQL에서 작성된 database입니다.

테이블 명 : member
스키마명 : login
칼럼 명
- id : 아이디 VARCHAR(45) PK NN
- pw : pw VARCHAR(128) NN
- pw2 : pw확인 VARCHAR(128) NN
- salt : 암호화된 솔트값 저장 VARCHAR(45) NN

[Import]
Server > Data Import > Import from Self-Contained File -> login_member.sql > Defalt Target Schema > Start Import

[Connect]
app.js 파일에서 아래 코드를 자신의 DB에 맞게 수정

var db = mysql.createConnection({
  host     : '************',
  user     : '************',
  password : '************',
  database : '************',
  port: '************',
});
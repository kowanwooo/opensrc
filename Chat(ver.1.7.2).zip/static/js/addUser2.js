const clockToggle = document.querySelector('.clock'); 
const clockBox = document.querySelector('.clockbox'); 

/* 시계 아이콘 클릭 시 이벤트 발생 */
clockToggle.addEventListener('click', function(){
    clockBox.classList.toggle('none');
});

// 위에는 토글 밑에는 시계
const clock = document.querySelector('.h1-clock');

/* Date객체를 통해 시, 분, 초 값을 받음 */
function getTime(){
    const time = new Date();
    const hour = time.getHours();
    const minutes = time.getMinutes();
    const seconds = time.getSeconds();
    clock.innerHTML = `${hour<10 ? `0${hour}`:hour}:${minutes<10 ? `0${minutes}`:minutes}:${seconds<10 ? `0${seconds}`:seconds}`
}

/* 1초 단위로 getTime()실행 */
function init(){
    setInterval(getTime, 1000);
}

init();

const clockFont = document.documentElement.querySelector('.clockfont');
const fas = document.documentElement.querySelectorAll('.fas');

document.addEventListener("DOMContentLoaded", function () {
    // 세션스토리지에 키: night, 밸류: nightMode 가져옴
    const night = sessionStorage.getItem("night", "nightMode");
    if (night === "nightMode") {
        document.documentElement.querySelector('body').classList.add('nightmode');
        clockBox.classList.add('clocknight');
    
        clockFont.classList.add('clockfontnight');
    
        for (var i = 0; i < fas.length; i++) {
            var item = fas.item(i);
            item.classList.add('fasnight');
        }
    } else { 
        clockBox.classList.remove('clocknight');
        clockFont.classList.remove('clockfontnight');
    
        for (var i = 0; i < fas.length; i++) {
            var item = fas.item(i);
            item.classList.remove('fasnight');
        }
}

const changerToggle = document.documentElement.querySelector('.changer');

/* 체인저 아이콘 클릭 시 이벤트 발생 */
changerToggle.addEventListener('click', function(){
    document.documentElement.querySelector('body').classList.toggle('nightmode');
    clockBox.classList.toggle('clocknight');

    clockFont.classList.toggle('clockfontnight');

    for (var i = 0; i < fas.length; i++) {
        var item = fas.item(i);
        item.classList.toggle('fasnight');
    }

    // 세션 스토리지의 0번 값을 가르킴
    const modeSelect = sessionStorage.key(0);
    if(modeSelect == 'night'){
        // 세션 스토리지의 값을 초기화
        sessionStorage.clear();

        // 세션 스토리지에 키: light, 밸류: lightMode 생성
        sessionStorage.setItem("light", "lightMode");
    } else{
        sessionStorage.clear();

        // 세션 스토리지에 키: Night, 밸류: NightMode 생성
        sessionStorage.setItem("night", "nightMode");
    }
}); 
})
/* 설치한 express 모듈 불러오기 */
const express = require("express");

/* 설치한 socket.io 모듈 불러오기 */
const socket = require("socket.io");

/* Node.js 기본 내장 모듈 불러오기 */
const http = require("http");

/* Node.js 기본 내장 모듈 불러오기 */
const fs = require("fs");

/* express 객체 생성 */
const app = express();
// 암호화를 위한 객체 생성
const crypto = require('crypto');

var bcrypt = require('bcrypt-nodejs');
/* express http 서버 생성 */
const server = http.createServer(app);

/* 생성된 서버를 socket.io에 바인딩 */
const io = socket(server);

const port = 3000;
const querystring = require('querystring');
const bodyParser = require('body-parser');
const path = require("path");

app.use(bodyParser.urlencoded({extended : false}));
app.use(bodyParser.json());

app.use("/static/css", express.static("./static/css"));
app.use("/static/js", express.static("./static/js"));

var mysql      = require('mysql');
const { json } = require("body-parser");
// 비밀번호는 별도의 파일로 분리해서 버전관리에 포함시키지 않아야 됨
var db = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '1234',
  database : 'new_schema',
  port: '3306',
});
  
db.connect((err) => {
  //if (err) throw err;
  console.log("Connected!");
});
  
db.query('SELECT * FROM member', function (error, results, fields) {
    if (error) {
        console.log(error);
    }
    console.log(results);
});

app.get("/", function (req, res) {
    fs.readFile("./static/login2.html", function (err, data) {
    if (err) {
        res.send("에러");
    } else {
        res.writeHead(200, { "Content-Type": "text/html" });
        res.write(data);
        res.end();
    }
    });
});
  
  app.get("/addUser2", function (req, res) {
    fs.readFile("./static/addUser2.html", function (err, data) {
    if (err) {
        res.send("에러");
    } else {
        res.writeHead(200, { "Content-Type": "text/html" });
        res.write(data);
        res.end();
    }
    });
  });

  let salt = Math.round((new Date().valueOf() * Math.random())) + "";
  const algorithm = 'aes-256-cbc';
  let salthash = salt; // 암호화 할 문구
  const key = crypto.scryptSync('ossproject','aplus', 32); // password, salt, byte 순서
  const iv = crypto.randomBytes(16); // 더 강력한 암호화를 위해 사용하는 초기화 벡터

  const cipher = crypto.createCipheriv(algorithm, key, iv); //key는 32바이트, iv는 16바이트
  let encryptsalt = cipher.update(salthash, 'utf8', 'base64');
  encryptsalt += cipher.final('base64');
  

  app.post('/addUser2', function(req, res){
      var hashPassword = crypto.createHash("sha256").update(req.body.pw + salt).digest("base64");
      var sql = 'INSERT INTO member(id, pw, pw2, salt) VALUES(?, ?, ?, ?)';
      var params = [req.body.id, hashPassword, hashPassword, encryptsalt];
      console.log('salthash : ', encryptsalt);

      db.query(sql,params, (err, result) => {
        if (err) {
          console.log(err);
        }
        console.log(result);
        
      });

      fs.readFile("./static/login2.html", function (err, data) {
        if (err) {
            res.send("에러");
        } else {
            res.writeHead(200, { "Content-Type": "text/html" });
            res.write(data);
            res.end();
        }
      });
    
  });
  
  app.post("/addUser2/login-in", function (req, res) {
    var id = req.body.id;
    var pwd = req.body.pwd;
    
    db.query('select * from member where id=?', [id], (err,rows) => {
        if(rows.length){
          if(rows[0].id===id){
            db.query('SELECT salt FROM member WHERE id=?', [id], (err, result) => {
              if (err) {
                console.log(err);
              }
              var salt = result[0].salt;
              const deciper = crypto.createDecipheriv(algorithm, key, iv);
              let decryptsalt = deciper.update(salt, 'base64', 'utf8');
              decryptsalt += deciper.final('utf8');
              console.log('decryptsalt : ', decryptsalt);

              var hashPassword = crypto.createHash("sha256").update(pwd + decryptsalt).digest("base64");
              console.log(hashPassword);
            db.query('select * from member where pw=?', [hashPassword], (err,rows) => {
              if(err){
                throw err;
              }else if(rows.length){
                
                fs.readFile("./static/start.html", function (err, data) {
                  if (err) {
                      res.send("에러");
                  } else {
                      res.writeHead(200, { "Content-Type": "text/html" });
                      res.write(data);
                      res.end();
                  }
                  
                  console.log("login!!!!");
                  });
              } else{
                console.log("pw false");
                }
              });
            })
        }
        }
        else{
          console.log("id false");
        }
      })
});  

    
  
  app.get('/index', function(req, res){
    fs.readFile('./static/index.html', function(err, data){
        if (err) {
            res.send("에러");
        } else {
            res.writeHead(200, { "Content-Type": "text/html" });
            res.write(data);
            res.end();
        }
        });
});

app.get('/game', function(req, res){
    fs.readFile('./static/game.html', function(err, data){
        if (err) {
            res.send("에러");
        } else {
            res.writeHead(200, { "Content-Type": "text/html" });
            res.write(data);
            res.end();
        }
        });
});

io.sockets.on("connection", function (socket) {
  /* 새로운 유저가 접속했을 경우 다른 소켓에게도 알려줌 */
    socket.on("newUser", function (name) {
    console.log(name + " 님이 접속하였습니다.");

    /* 소켓에 이름 저장해두기 */
    socket.name = name;

    /* 모든 소켓에게 전송 */
    io.sockets.emit("update", {
        type: "connect",
        name: "SERVER",
        message: name + "님이 접속하였습니다.",
        addname: name,
    });
});

  /* 전송한 메시지 받기 */
    socket.on("message", function (data) {
    /* 받은 데이터에 누가 보냈는지 이름을 추가 */
    data.name = socket.name;

    console.log(data);

    /* 보낸 사람을 제외한 나머지 유저에게 메시지 전송 */
    socket.broadcast.emit("update", data);
});

  /* 접속 종료 */
    socket.on("disconnect", function () {
    console.log(socket.name + "님이 나가셨습니다.");

    /* 나가는 사람을 제외한 나머지 유저에게 메시지 전송 */
    socket.broadcast.emit("update", {
        type: "disconnect",
        name: "SERVER",
        message: socket.name + "님이 나가셨습니다.",
        removename: socket.name,
        });
    });
});

server.listen(port, () => {
    console.log(`server is listening at localhost:${port}`);
});

[1 주차 ver1.0.0]
- Node.js 서버 구축
- index.html 작성 및 CSS, JS 파일 서버단에 연결

[2 주차 ver1.1.0]
- html 작성
- JavaScript 서버와 클라이언트 처리

[3주차 ver1.2.0]
- CSS 작성

[4주차 ver1.3.0]
- 메인 화면 HTML 작성 및 CSS, JS 파일 연결

[5주차 ver1.4.0]
- 메인 화면 게임 서비스 HTML, CSS, JS 작성
- 시계 기능 추가

[6주차 ver1.5.0]
- 메인화면 및 토크 페이지 나이트 모드 추가
- 메인 화면 Notice기능 추가

[7주차 ver1.6.0]
- 메인 페이지, 토크 페이지 미디어 쿼리 추가
- 토크 페이지 Prompt > Input타입으로 변경
- 모든 페이지 나이트 모드 추가 및 연동
- 게임 페이지 시계 및 나이트 모드 추가

[8주차 ver1.7.0]
- 게임 페이지 토크 토글 추가
- 게임 페이지 영상 추가 및 미디어쿼리 추가
- 게임 페이지 스네이크 게임 요소 추가

[9주차 ver1.7.1]
- 오류 수정
- 변수 변경
1. Start
- JavaScript
togglingBtns > clockToggle
box > clockBox
noticetoggle > noticeToggle
noticebox > noticeBox
nmode > nightMode
lmode > lightMode
wr1 > wrap1
wr2 > wrap2
h1 > hWrap1
h2 > hWrap2
clockfont > clockFont
changer > modeChanger
mode > modeSelect

2. Index
- HTML
test > text

- JavaScript
namebox > nameBox
namesubmit > nameSubmit
nameinput > nameInput
Function send( ) 내 message > sendMessage
indexpg > indexBody

3. Game
- CSS
gmpgnight > gamebodynight
h1night > nighth1

- JavaScript
gmpg > gameBody
h1night > nighth1

[10주차 ver1.7.2]
- DB연결
- 로그인 및 회원가입 기능 구현
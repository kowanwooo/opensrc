[1 주차 ver1.0.0]
- Node.js 서버 구축
- index.html 작성 및 CSS, JS 파일 서버단에 연결

[2 주차 ver1.1.0]
- html 작성
- JavaScript 서버와 클라이언트 처리

[3주차 ver1.2.0]
- CSS 작성

[4주차 ver1.3.0]
- 메인 화면 HTML 작성 및 CSS, JS 파일 연결

[5주차 ver1.4.0]
- 메인 화면 게임 서비스 HTML, CSS, JS 작성
- 시계 기능 추가
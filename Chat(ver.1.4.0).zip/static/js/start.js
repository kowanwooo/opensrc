const togglingBtns = document.querySelector('.clock'); 
const box = document.querySelector('.clockbox'); 

togglingBtns.addEventListener('click', function(){
    box.classList.toggle('open');
});
// 위에는 토글 밑에는 시계
const clock = document.querySelector('.h1-clock');


function getTime(){
    const time = new Date();
    const hour = time.getHours();
    const minutes = time.getMinutes();
    const seconds = time.getSeconds();
    clock.innerHTML = `${hour<10 ? `0${hour}`:hour}:${minutes<10 ? `0${minutes}`:minutes}:${seconds<10 ? `0${seconds}`:seconds}`
}

function init(){
    setInterval(getTime, 1000);
}

init();
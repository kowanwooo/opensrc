[1 주차 ver1.0.0]
- Node.js 서버 구축
- index.html 작성 및 CSS, JS 파일 서버단에 연결

[2 주차 ver1.1.0]
- html 작성
- JavaScript 서버와 클라이언트 처리

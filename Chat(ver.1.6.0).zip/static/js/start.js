const togglingBtns = document.querySelector('.clock'); 
const box = document.querySelector('.clockbox'); 
var nightpg = 0;

togglingBtns.addEventListener('click', function(){
    box.classList.toggle('none');
});

const noticetoggle = document.querySelector('.notice'); 
const noticebox = document.querySelector('.noticebox'); 

noticetoggle.addEventListener('click', function(){
    noticebox.classList.toggle('none');
});


// 위에는 토글 밑에는 시계
const clock = document.querySelector('.h1-clock');


function getTime(){
    const time = new Date();
    const hour = time.getHours();
    const minutes = time.getMinutes();
    const seconds = time.getSeconds();
    clock.innerHTML = `${hour<10 ? `0${hour}`:hour}:${minutes<10 ? `0${minutes}`:minutes}:${seconds<10 ? `0${seconds}`:seconds}`
}

function init(){
    setInterval(getTime, 1000);
}

init();


document.addEventListener("DOMContentLoaded", function () {
    const night = sessionStorage.getItem("night", "nmode");
    if (night === "nmode") {
        document.documentElement.querySelector('body').classList.add('nightmode');

        var wr1 = document.documentElement.querySelector('.wrap');
        var h1 = wr1.querySelectorAll('h1');
        
        for (var i = 0; i < h1.length; i++) {
            var item = h1.item(i);
            item.classList.add('nighth1');
        }
    
        var wr2 = document.documentElement.querySelector('.wrap2');
        var h2 = wr2.querySelectorAll('h1');
        
        for (var i = 0; i < h2.length; i++) {
            var item = h2.item(i);
            item.classList.add('nighth1');
        }
    
        var btn = document.documentElement.querySelectorAll('.button');
    
        for (var i = 0; i < btn.length; i++) {
            var item = btn.item(i);
            item.classList.add('btnnight');
        }
    
        var clock = document.documentElement.querySelector('.clockbox');
        clock.classList.add('clocknight');
    
        var clockfont = document.documentElement.querySelector('.clockfont');
        clockfont.classList.add('clockfontnight');
    
        var fas = document.documentElement.querySelectorAll('.fas');
        for (var i = 0; i < fas.length; i++) {
            var item = fas.item(i);
            item.classList.add('fasnight');
        }
    } else {
        document.documentElement.querySelector('body').classList.remove('nightmode');

        var wr1 = document.documentElement.querySelector('.wrap');
        var h1 = wr1.querySelectorAll('h1');
        
        for (var i = 0; i < h1.length; i++) {
            var item = h1.item(i);
            item.classList.remove('nighth1');
        }
    
        var wr2 = document.documentElement.querySelector('.wrap2');
        var h2 = wr2.querySelectorAll('h1');
        
        for (var i = 0; i < h2.length; i++) {
            var item = h2.item(i);
            item.classList.remove('nighth1');
        }
    
        var btn = document.documentElement.querySelectorAll('.button');
    
        for (var i = 0; i < btn.length; i++) {
            var item = btn.item(i);
            item.classList.remove('btnnight');
        }
    
        var clock = document.documentElement.querySelector('.clockbox');
        clock.classList.remove('clocknight');
    
        var clockfont = document.documentElement.querySelector('.clockfont');
        clockfont.classList.remove('clockfontnight');
    
        var fas = document.documentElement.querySelectorAll('.fas');
        for (var i = 0; i < fas.length; i++) {
            var item = fas.item(i);
            item.classList.remove('fasnight');
        }
    }
})

const changer = document.documentElement.querySelector('.changer');
changer.addEventListener('click', function(){
    document.documentElement.querySelector('body').classList.toggle('nightmode');

    var wr1 = document.documentElement.querySelector('.wrap');
    var h1 = wr1.querySelectorAll('h1');
    
    for (var i = 0; i < h1.length; i++) {
        var item = h1.item(i);
        item.classList.toggle('nighth1');
    }

    var wr2 = document.documentElement.querySelector('.wrap2');
    var h2 = wr2.querySelectorAll('h1');
    
    for (var i = 0; i < h2.length; i++) {
        var item = h2.item(i);
        item.classList.toggle('nighth1');
    }

    var btn = document.documentElement.querySelectorAll('.button');

    for (var i = 0; i < btn.length; i++) {
        var item = btn.item(i);
        item.classList.toggle('btnnight');
    }

    var clock = document.documentElement.querySelector('.clockbox');
    clock.classList.toggle('clocknight');

    var clockfont = document.documentElement.querySelector('.clockfont');
    clockfont.classList.toggle('clockfontnight');

    var fas = document.documentElement.querySelectorAll('.fas');
    for (var i = 0; i < fas.length; i++) {
        var item = fas.item(i);
        item.classList.toggle('fasnight');
    }

    var mode = sessionStorage.key(0);
    if(mode == 'night'){
        sessionStorage.clear();
        sessionStorage.setItem("light", "lmode");
    } else{
        sessionStorage.clear();
        sessionStorage.setItem("night", "nmode");
    }
}); 







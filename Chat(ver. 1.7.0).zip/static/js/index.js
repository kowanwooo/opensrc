var socket = io()
const namebox = document.querySelector('.namebox');
const namesubmit = document.querySelector('.namesubmit');


/* 접속 되었을 때 실행 */
socket.on('connect', function() {
  namesubmit.addEventListener("click", function() {
    const nameinput = document.getElementById('nameinput').value;
    var name = nameinput;

  /* 이름이 빈칸인 경우 */
    if(!name) {
      name = '익명'
    }
  
  /* 서버에 새로운 유저가 왔다고 알림 */
    socket.emit('newUser', name)
  })
})

/* 서버로부터 데이터 받은 경우 */
socket.on('update', function(data) {
  var chat = document.getElementById('chat')
  var message = document.createElement('div')
  var node = document.createTextNode(`${data.name} : ${data.message}`)
  var className = ''

  // 타입에 따라 적용할 클래스를 다르게 지정
  switch(data.type) {
    case 'message':
      className = 'other'
      break

    case 'connect':
      className = 'connect'
      break

    case 'disconnect':
      className = 'disconnect'
      break
  }

    message.classList.add(className)
    message.appendChild(node)
    chat.appendChild(message)
})

/* 메시지 전송 함수 */
function send() {
  // 입력되어있는 데이터 가져오기
  var message = document.getElementById('test').value
  
  // 가져왔으니 데이터 빈칸으로 변경
  document.getElementById('test').value = ''

  // 내가 전송할 메시지 클라이언트에게 표시
  var chat = document.getElementById('chat')
  var msg = document.createElement('div')
  var node = document.createTextNode(message)
  msg.classList.add('me')
  msg.appendChild(node)
  chat.appendChild(msg)

  // 서버로 message 이벤트 전달 + 데이터와 함께
  socket.emit('message', {type: 'message', message: message})
}

function enterkey(){
  if(window.event.keyCode == 13){
    send();
  }
}

const togglingBtns = document.querySelector('.clock'); 
const box = document.querySelector('.clockbox'); 

togglingBtns.addEventListener('click', function(){
    box.classList.toggle('none');
});

namesubmit.addEventListener('click', function(){
  namebox.classList.toggle('none');
});



const clock = document.querySelector('.h1-clock');

function getTime(){
    const time = new Date();
    const hour = time.getHours();
    const minutes = time.getMinutes();
    const seconds = time.getSeconds();
    clock.innerHTML = `${hour<10 ? `0${hour}`:hour}:${minutes<10 ? `0${minutes}`:minutes}:${seconds<10 ? `0${seconds}`:seconds}`
}

function init(){
    setInterval(getTime, 1000);
}

init();


document.addEventListener("DOMContentLoaded", function () {
  const night = sessionStorage.getItem("night", "nmode");
  if (night === "nmode") {
    var indexpg = document.documentElement.querySelector('body');
    var mnight = indexpg.querySelectorAll('.indexpg');
    for (var i = 0; i < mnight.length; i++) {
        var item = mnight.item(i);
        item.classList.add('mnight');
    }

    document.documentElement.querySelector('body').classList.add('nightmode');

    var clock = document.documentElement.querySelector('.clockbox');
    clock.classList.add('clocknight');

    var clockfont = document.documentElement.querySelector('.clockfont');
    clockfont.classList.add('clockfontnight');

    var fas = document.documentElement.querySelectorAll('.fas');
    for (var i = 0; i < fas.length; i++) {
        var item = fas.item(i);
        item.classList.add('fasnight');
    }
  } else{
    var indexpg = document.documentElement.querySelector('body');
    var mnight = indexpg.querySelectorAll('.indexpg');
    for (var i = 0; i < mnight.length; i++) {
        var item = mnight.item(i);
        item.classList.remove('mnight');
    }

    document.documentElement.querySelector('body').classList.remove('nightmode');

    var clock = document.documentElement.querySelector('.clockbox');
    clock.classList.remove('clocknight');

    var clockfont = document.documentElement.querySelector('.clockfont');
    clockfont.classList.remove('clockfontnight');

    var fas = document.documentElement.querySelectorAll('.fas');
    for (var i = 0; i < fas.length; i++) {
        var item = fas.item(i);
        item.classList.remove('fasnight');
    }
  }
})

const changer = document.querySelector('.changer'); 
changer.addEventListener('click', function(){
  var indexpg = document.documentElement.querySelector('body');
    var mnight = indexpg.querySelectorAll('.indexpg');
    for (var i = 0; i < mnight.length; i++) {
        var item = mnight.item(i);
        item.classList.toggle('mnight');
    }
    
    document.documentElement.querySelector('body').classList.toggle('nightmode');

    var clock = document.documentElement.querySelector('.clockbox');
    clock.classList.toggle('clocknight');

    var clockfont = document.documentElement.querySelector('.clockfont');
    clockfont.classList.toggle('clockfontnight');

    var fas = document.documentElement.querySelectorAll('.fas');
    for (var i = 0; i < fas.length; i++) {
        var item = fas.item(i);
        item.classList.toggle('fasnight');
    }
    
    //세션 스토리지
    var mode = sessionStorage.key(0);
    if(mode == 'night'){
        sessionStorage.clear();
        sessionStorage.setItem("light", "lmode");
    } else{
        sessionStorage.clear();
        sessionStorage.setItem("night", "nmode");
    }
})
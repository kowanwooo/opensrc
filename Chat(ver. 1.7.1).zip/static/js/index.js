/* Socket.io 실행 후 해당 객체를 리턴받아 socket변수에 담음 */
var socket = io()

const nameBox = document.querySelector('.namebox');
const nameSubmit = document.querySelector('.namesubmit');

/* 접속 되었을 때 실행 */
socket.on('connect', function() {
  nameSubmit.addEventListener("click", function() {
    const nameInput = document.getElementById('nameinput').value;
    var name = nameInput;

  /* 이름이 빈칸인 경우 */
    if(!name) {
      name = '익명'
    }
  
  /* 서버에 새로운 유저가 왔다고 알림 */
    socket.emit('newUser', name)
  })
})

/* 서버로부터 데이터 받은 경우 */
socket.on('update', function(data) {
  var chat = document.getElementById('chat')
  var message = document.createElement('div')
  var node = document.createTextNode(`${data.name} : ${data.message}`)
  var className = ''

  // 타입에 따라 적용할 클래스를 다르게 지정
  switch(data.type) {
    case 'message':
      className = 'other'
      break

    case 'connect':
      className = 'connect'
      break

    case 'disconnect':
      className = 'disconnect'
      break
  }

    message.classList.add(className)
    message.appendChild(node)
    chat.appendChild(message)
})

/* 메시지 전송 함수 */
function send() {
  // 입력되어있는 데이터 가져오기
  var sendMessage = document.getElementById('text').value
  
  // 가져왔으니 데이터 빈칸으로 변경
  document.getElementById('text').value = ''

  // 내가 전송할 메시지 클라이언트에게 표시
  var chat = document.getElementById('chat')
  var msg = document.createElement('div')
  var node = document.createTextNode(sendMessage)
  msg.classList.add('me')
  msg.appendChild(node)
  chat.appendChild(msg)

  // 서버로 message 이벤트 전달 + 데이터와 함께
  socket.emit('message', {type: 'message', sendMessage: sendMessage})
}

/* 엔터키로 메세지 전송 */
function enterkey(){
  if(window.event.keyCode == 13){
    send();
  }
}

/* 이름 제출 시 이벤트 발생 */
nameSubmit.addEventListener('click', function(){
  nameBox.classList.toggle('none');
});

const clockToggle = document.querySelector('.clock'); 
const clockBox = document.querySelector('.clockbox'); 

/* 시계 아이콘 클릭 시 이벤트 발생 */
clockToggle.addEventListener('click', function(){
  clockBox.classList.toggle('none');
});

const clock = document.querySelector('.h1-clock');

/* Date객체를 통해 시, 분, 초 값을 받음 */
function getTime(){
  const time = new Date();
  const hour = time.getHours();
  const minutes = time.getMinutes();
  const seconds = time.getSeconds();
  clock.innerHTML = `${hour<10 ? `0${hour}`:hour}:${minutes<10 ? `0${minutes}`:minutes}:${seconds<10 ? `0${seconds}`:seconds}`
}

/* 1초 단위로 getTime()실행 */
function init(){
    setInterval(getTime, 1000);
}

init();

const indexBody = document.documentElement.querySelector('body');
const clockFont = document.documentElement.querySelector('.clockfont');
const fas = document.documentElement.querySelectorAll('.fas');

/* DOM로드 시 이벤트 발생 */
document.addEventListener("DOMContentLoaded", function () {
  // 세션스토리지에 키: night, 밸류: nightMode를 가져옴
  const night = sessionStorage.getItem("night", "nightMode");
  if (night === "nightMode") {

    document.documentElement.querySelector('body').classList.add('nightmode');

    clockBox.classList.add('clocknight');

    clockFont.classList.add('clockfontnight');

    for (var i = 0; i < fas.length; i++) {
        var item = fas.item(i);
        item.classList.add('fasnight');
    }

  } else{
    clockBox.classList.remove('clocknight');

    clockFont.classList.remove('clockfontnight');

    for (var i = 0; i < fas.length; i++) {
        var item = fas.item(i);
        item.classList.remove('fasnight');
    }
  }

  const changerToggle = document.documentElement.querySelector('.changer'); 

  /* 체인저 아이콘 클릭 시 이벤트 발생 */
  changerToggle.addEventListener('click', function(){
  document.documentElement.querySelector('body').classList.toggle('nightmode');

  clockBox.classList.toggle('clocknight');

  clockFont.classList.toggle('clockfontnight');

  for (var i = 0; i < fas.length; i++) {
    var item = fas.item(i);
    item.classList.toggle('fasnight');
  }
    
  // 세션 스토리지의 0번 값을 가르킴
  const modeSelect = sessionStorage.key(0);
  if(modeSelect == 'night'){
    // 세션 스토리지의 값을 초기화
    sessionStorage.clear();

    // 세션 스토리지에 키: light, 밸류: lightMode 생성
    sessionStorage.setItem("light", "lightMode");
  } else{
    sessionStorage.clear();

    // 세션 스토리지에 키: Night, 밸류: NightMode 생성
    sessionStorage.setItem("night", "nightMode");
  }
});
})
